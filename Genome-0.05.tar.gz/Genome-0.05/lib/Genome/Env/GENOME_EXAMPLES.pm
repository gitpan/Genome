package Genome::Env::GENOME_MODEL_DATA;
our $VERSION = $Genome::VERSION;
1;
