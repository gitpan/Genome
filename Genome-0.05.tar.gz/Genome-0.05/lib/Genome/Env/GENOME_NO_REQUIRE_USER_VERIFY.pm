package Genome::Env::GENOME_NO_REQUIRE_USER_VERIFY;
our $VERSION = $Genome::VERSION;
1;
