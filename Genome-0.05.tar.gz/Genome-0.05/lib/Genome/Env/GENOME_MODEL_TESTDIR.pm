package Genome::Env::GENOME_MODEL_TESTDIR;
our $VERSION = $Genome::VERSION;
1;
